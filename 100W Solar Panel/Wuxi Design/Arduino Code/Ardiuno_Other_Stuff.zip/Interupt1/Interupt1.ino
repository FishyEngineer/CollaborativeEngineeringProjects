int pbIn = 2;          // Digital input on pin 2
int ledOut = 4;        // The output LED pin 
int state = LOW;       // The input state 
void setup() 
{                 
// Set up the digital Pin 2 to an Input and Pin 4 to an Output 
pinMode(pbIn, INPUT);  
pinMode(ledOut, OUTPUT); 
} 
void loop()                      
{ 
state = digitalRead(pbIn);      //Read the button   
digitalWrite(ledOut, state);    //write the LED state 
//Simulate a long running process or complex task 
for (int i = 0; i < 100; i++)   
{     
// do nothing but waste some time 
delay(10);  
}
}
