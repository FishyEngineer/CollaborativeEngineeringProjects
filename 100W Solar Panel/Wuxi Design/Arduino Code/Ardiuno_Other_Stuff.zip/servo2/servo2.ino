//http://www.dummies.com/how-to/content/how-to-control-the-speed-of-a-dc-motor-with-the-ar.html
int E1 = 4;    
int potPin = A0;
int motorPin = 5;
int potValue = 0;
int motorValue = 0;

void setup() {
 Serial.begin(9600);
}

void loop() {
 digitalWrite(E1,HIGH); 
 potValue = analogRead(potPin);  
 motorValue = map(potValue, 0, 1023, 0, 255);
if(motorValue > 100) {
 analogWrite(motorPin, motorValue);
} else {
 digitalWrite(motorPin, LOW);
} 
 Serial.print("potentiometer = " );     
 Serial.print(potValue);
 Serial.print("\t motor = ");
 Serial.println(motorValue);
 delay(2);    
}

