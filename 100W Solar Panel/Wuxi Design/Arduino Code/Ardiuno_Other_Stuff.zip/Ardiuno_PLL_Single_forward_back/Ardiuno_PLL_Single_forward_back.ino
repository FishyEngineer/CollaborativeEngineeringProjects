//Arduino PLL Speed Control? 
int E1 = 4;    
int M1 = 5;                            
  
void setup()  
{  
    pinMode(M1, OUTPUT);     
}  
  
void loop()  
{  
  int value; 
  for(value = 0 ; value <= 255; value+=5)  
  {  
    digitalWrite(E1,HIGH);    
    analogWrite(M1, value);   //PLL Speed Control 
    delay(300);  
  }   
    for(value = 0 ; value <= 255; value+=5)  
  {  
    digitalWrite(E1,LOW);    
    analogWrite(M1, value);   //PLL Speed Control 
    delay(300);  
  }   
}

