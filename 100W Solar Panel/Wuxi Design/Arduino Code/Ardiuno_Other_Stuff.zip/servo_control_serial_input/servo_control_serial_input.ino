// Sweep
// by BARRAGAN <http://barraganstudio.com> 
// This example code is in the public domain.


#include <Servo.h> 
#include <LiquidCrystal.h>

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);
 
Servo myservo;  // create servo object to control a servo 
                // a maximum of eight servo objects can be created 
 
int pos = 90;    // variable to store the servo position 

int red = 6 ;
int green = 7 ;
int uno_led = 13 ;
 
void setup() 
{
  lcd.begin(16, 2);
  lcd.setCursor(6,0);
  lcd.print(pos);                  

  
  pinMode ( green, OUTPUT ); // green
  pinMode ( red, OUTPUT ) ; // red
  pinMode ( uno_led, OUTPUT ) ;
  
  myservo.attach(9);  // attaches the servo on pin 9 to the servo object 
 
  Serial.begin(9600);
} 
 
 
void loop() 
{
  digitalWrite ( uno_led, LOW ) ;
  
    if (Serial.available() > 0)    
    {
      int target = Serial.parseInt(); //The value that we enter into the serial monitor is the target

//      pos = pos ;
      
      if ( target < pos )
        {      
            for(pos = pos; pos >= target; pos--)  // goes from 0 degrees to 180 degrees 
              {                                   // in steps of 1 degree 
                myservo.write(pos);              // tell servo to go to position in variable 'pos' 
                delay(30);                      // waits 30ms for the servo to reach the position 

                if ( pos != target )
                  {
                    digitalWrite ( green, LOW ) ;
                    digitalWrite ( red, HIGH ) ;
                  }
                else
                  {
                    digitalWrite ( green, HIGH ) ;
                    digitalWrite ( red, LOW ) ;
                  }

                lcd.setCursor(6,0);
                lcd.print(pos);                  
              }
        }
      else
        {
            for(pos = pos; pos <= target; pos++)  // goes from 0 degrees to 180 degrees 
              {                                  // in steps of 1 degree 
                myservo.write(pos);              // tell servo to go to position in variable 'pos' 
                delay(30);                // waits 15ms for the servo to reach the position 

                if ( pos != target )
                  {
                    digitalWrite ( green, LOW ) ;
                    digitalWrite ( red, HIGH ) ;
                  }
                else
                  {
                    digitalWrite ( green, HIGH ) ;
                    digitalWrite ( red, LOW ) ;
                  }

                lcd.setCursor(6,0);
                lcd.print(pos);
                
              }
        }
    }
   
     delay ( 1000 ) ;
     digitalWrite ( green, LOW ) ;
}
