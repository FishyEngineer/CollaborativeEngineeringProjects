int inPin2 = 2;
int inPin3 = 3;
int outPin12 = 12;
int outPin13 = 13; 
int state = HIGH;
int reading;
int previous = LOW;
long time = 0; 
long debounce = 200;

void setup()
{
  pinMode(inPin2, INPUT);
  pinMode(inPin3, INPUT);
  pinMode(outPin12, OUTPUT);
  pinMode(outPin13, OUTPUT);
}

void loop()
{
  reading = digitalRead(inPin2);
  reading = digitalRead(inPin3);
  if (reading == HIGH && previous == LOW && millis() - time > debounce) {
    if (state == HIGH)
      state = LOW;
    else
      state = HIGH;
    time = millis();    
  }
  digitalWrite(outPin12, state);
  digitalWrite(outPin13, state);
  previous = reading;
}


