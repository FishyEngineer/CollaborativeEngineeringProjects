int pbIn2 = 2;          // Digital input on pin 2
int pbIn3 = 3;          // Digital input on pin 3
int ledOut12 = 12;      // The output LED pin 12
int ledOut13 = 12;      // The output LED pin 13
int state2 = LOW;       // The input state
int state3 = LOW;       // The input state

void setup()
{                
  // Set up the digital Pin 2 to an Input and Pin 4 to an Output
  pinMode(pbIn2, INPUT); 
  pinMode(pbIn3, INPUT); 
  pinMode(ledOut12, OUTPUT);
  pinMode(ledOut13, OUTPUT);
}

void loop()                     
{
  state2 = digitalRead(pbIn2);      //Read the button
  state3 = digitalRead(pbIn3);      //Read the button
  digitalWrite(ledOut12, state2);   //write the LED state
  digitalWrite(ledOut13, state3);   //write the LED state
}


