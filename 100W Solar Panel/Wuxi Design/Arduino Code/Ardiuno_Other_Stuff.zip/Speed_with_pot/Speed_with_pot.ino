//Arduino PLL Speed Control using pot
int E1 = 4;    
int M1 = 5;                           
  
void setup()  
{  
  pinMode(M1, OUTPUT); 
  Serial.begin(9600);   
}  
  
void loop()  
{  
  int value; 
  for(value = 0 ; value <= 255; value+=5)  
  {  
    digitalWrite(E1,HIGH);           
    analogWrite(M1, value);   //PLL Speed Control  
    int sensorValue = analogRead(A0);
    Serial.println(sensorValue);
    delay(30); 
  }   
}
