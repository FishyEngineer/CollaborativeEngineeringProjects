//Arduino PLL Speed Control using pot
int E1 = 4;    
int M1 = 5;                           
  
void setup()  
{  
  pinMode(M1, OUTPUT); 
  Serial.begin(9600);   
}  
  
void loop()  
{  
    int sensorValue = analogRead(A0);
    int value = analogRead(A0)/4; 
    digitalWrite(E1,HIGH);           
    analogWrite(M1, value);   //PLL Speed Control  
    Serial.println(sensorValue);
    delay(30);   
}
