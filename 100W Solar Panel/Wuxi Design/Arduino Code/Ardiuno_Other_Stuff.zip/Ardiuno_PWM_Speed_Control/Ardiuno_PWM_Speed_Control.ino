//Arduino PWM Speed Control:
int E1 = 5;  
int M1 = 4;                         

void setup() 
{ 
    pinMode(M1, OUTPUT);   
} 

void loop() 
{ 
  int value;
  for(value = 0 ; value <= 255; value+=5) 
  { 
    digitalWrite(M1,HIGH);         
    analogWrite(E1, value);   //PWM Speed Control
    delay(30); 
  }  
}
