//WUXI Professional School of Science and Technology
//11/13/2014
//Code to control Single Tracker Solar Panel
int E1 = 4;    
int potPin = A0;
int motorPin = 5;
int potValue = 0;
int motorValue = 0;
int countValue = 0;

void setup() {
 Serial.begin(9600);
}

void loop() {
 digitalWrite(E1,HIGH); 
 potValue = analogRead(potPin);  
 motorValue = map(potValue, 0, 1023, 0, 255);
if(motorValue > 100) { //set upper limit value based on amount of movement needed per step
 analogWrite(motorPin, motorValue);
} else {
 digitalWrite(motorPin, LOW);
} 
 Serial.print("potentiometer = " );     
 Serial.print(potValue);
 Serial.print("\t motor = ");
 Serial.println(motorValue);
 Serial.print("\t count = ");
 Serial.println(countValue);
 delay(100);
//increment the count and turn the motor back off and wait until next motor step needed
 countValue = countValue+1;
 motorValue = 0;
 analogWrite(motorPin, motorValue);
 delay(5000); 
}
