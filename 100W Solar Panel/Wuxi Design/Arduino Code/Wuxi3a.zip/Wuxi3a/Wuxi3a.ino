//WUXI Professional School of Science and Technology
//11/13/2014
//Code to control Single Tracker Solar Panel & Limit Switches
int pbIn2 = 2;
int pbIn3 = 3;
int ledOut12 = 12;
int ledOut13 = 13;
int state2 = HIGH;
int state3 = HIGH;
int E1 = 4;    
int potPin = A0;
int motorPin = 5;
int potValue = 0;
int motorValue = 0;
int countValue = 0;

void setup() {
 pinMode(pbIn2, INPUT); 
 pinMode(pbIn3, INPUT); 
 pinMode(ledOut12, OUTPUT);
 pinMode(ledOut13, OUTPUT);
 Serial.begin(9600);
}

void loop() {
 state2 = digitalRead(pbIn2);
 state3 = digitalRead(pbIn3);
 digitalWrite(ledOut12, !state2);
 digitalWrite(ledOut13, !state3);
 digitalWrite(E1,HIGH); 
 potValue = analogRead(potPin); 
//has either limit switch been hit? 
if(state2 == LOW || state3 == LOW) { 
 motorValue = 0;
} else {
 motorValue = map(potValue, 0, 1023, 0, 255);
} 
if(motorValue > 100) { //set upper limit value based on amount of movement needed per step
} else {
 digitalWrite(motorPin, LOW);
} 
if(countValue > 10) { //set upper limit value based on amount of movement needed per step
 digitalWrite(E1,LOW);
 analogWrite(motorPin, motorValue);
 delay(100*countValue);// delay for panel return
 countValue = 0;
} else {
 analogWrite(motorPin, motorValue);
} 
 Serial.print("potentiometer = " );     
 Serial.print(potValue);
 Serial.print("\t motor = ");
 Serial.println(motorValue);
 Serial.print("\t count = ");
 Serial.println(countValue);
 delay(100);
//increment the count and turn the motor back off and wait until next motor step needed
 countValue = countValue+1;
 motorValue = 0;
 analogWrite(motorPin, motorValue);
 delay(1000); 
}
