//WUXI Professional School of Science and Technology
//11/13/2014
//Code to control Single Axis Tracker Solar Panel & Limit Switches
int pbIn2 = 2;
int pbIn3 = 3;
 //The two limit switches should be physically connected to pins 2 and 3 of the Arduino board through 10K resistors.
int ledOut12 = 12;
int ledOut13 = 13;
//The two limit switch LEDs are connect to pins 12 and 13 of the Arduino baord through 220 resistors.
//When the state is high the limit switches is not engaged, i.e. the solar panel has not hit the limit switch yet 
int state2 = HIGH;
int state3 = HIGH;
//The states should both be high and would translate into the limit switches not being engagued.
int E1 = 4; 
//This state of this pin enables or disable the motor drive.
int potPin = A0;
//The pot wiper should be connected to the A0 pin
int motorPin = 5;
//This state of this pin determines the direction of rotation of the motor.
int potValue = 0;
//Initially the pot value is set equal to zero
int motorValue = 0;
//Initially the motor power value is set equal to zero
int countValue = 0;
//Initially the count value is set equal to zero
void setup() {
 pinMode(pbIn2, INPUT); //This deines the pbIn2 pin as an input
 pinMode(pbIn3, INPUT); //This deines the pbIn3 pin as an input
 pinMode(ledOut12, OUTPUT); //This deines the ledOut12 pin as an output
 pinMode(ledOut13, OUTPUT); //This deines the ledOut13 pin as an output
 Serial.begin(9600); //This commands facilitates the communication with the PC
}

void loop() {
 state2 = digitalRead(pbIn2);     //state2 is set equal to level of the pbIn2 pin
 state3 = digitalRead(pbIn3);     //state3 is set equal to level of the pbIn3 pin
 digitalWrite(ledOut12, !state2); //the inverse of state2 is written out to the ledOut12 pin
 digitalWrite(ledOut13, !state3); //the inverse of state3 is written out to the ledOut13 pin
 digitalWrite(E1,HIGH);           //The motor drive is eneabled
 potValue = analogRead(potPin);   //potValue is set equal to the analog voltage measured on the A0 pin

if(state2 == LOW || state3 == LOW) { 
 motorValue = 0;
 //has either limit switch been hit?
 //if so then set the motor power level to zero which will stop the motor
} else {
 motorValue = map(potValue, 0, 1023, 0, 255); //the motorValue is "mapped" to the potValue or divided by 4.  
} 
if(motorValue > 100) { //set upper limit value based on amount of movement needed per step
} else {
 digitalWrite(motorPin, LOW);
} 
if(countValue > 10) { //this is set based on the number of steps needed to go each day
 digitalWrite(E1,LOW); 
 analogWrite(motorPin, motorValue);
 delay(100*countValue);//time for panel return
 countValue = 0;
} else {
 analogWrite(motorPin, motorValue);
} 
 Serial.print("potentiometer = " );     
 Serial.print(potValue);
 Serial.print("\t motor = ");
 Serial.println(motorValue);
 Serial.print("\t count = ");
 Serial.println(countValue);
 delay(100);
//increment the count and turn the motor back off and wait until next motor step needed
 countValue = countValue+1;
 motorValue = 0;
 analogWrite(motorPin, motorValue);
 delay(1000); //adjust this number so that it will be equal to one update per hour.
}
